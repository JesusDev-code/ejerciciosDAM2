package com.example.tfg_apli.data.model

data class Proyecto(
    val id: Long,
    val nombre: String,
    val descripcion: String
)