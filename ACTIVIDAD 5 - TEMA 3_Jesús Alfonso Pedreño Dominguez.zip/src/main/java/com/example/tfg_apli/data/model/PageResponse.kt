package com.example.tfg_apli.data.model

data class PageResponse<T>(
    val content: List<T>
)