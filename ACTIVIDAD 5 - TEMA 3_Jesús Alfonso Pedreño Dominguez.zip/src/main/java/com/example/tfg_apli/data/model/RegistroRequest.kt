package com.example.tfg_apli.data.model

data class RegistroRequest(
    val nombre: String,
    val email: String
)